import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Scanner;

public class SuifengDailyRecordIndex {
	
	private String suifengDailyRecordPath = "";
	
	private String reg = "";
	
	private ArrayList<String> fileList = null;
	
	public SuifengDailyRecordIndex(){
		initConfig();
	}
	
	private void initConfig(){
		Properties prop = new Properties();
		try {
			prop.load(new FileInputStream(new File("config")));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		suifengDailyRecordPath = prop.getProperty("suifengDailyRecordPath");
	}
	
	private void callFromInput(String input){
		if("exit".equals(input)){
			System.exit(0);
		}else{
			index(input);
		}
	}
	
	private void start(){
		System.out.println("\r\n");
		System.out.print("Please input something for search: ");
		Scanner scan = new Scanner(System.in);
		callFromInput(scan.nextLine().trim());
	}
	
	private void index(String reg) {
		
		this.reg = reg;
		
		Map<String,ArrayList<String>> tMap = getAllFiles();
		ArrayList<String> tList = new ArrayList<String>(tMap.keySet());
		Collections.sort(tList);
		
		fileList = new ArrayList<String>();
		int z = 0;
		
		for(String date : tList){
			
			ArrayList<String> aList = tMap.get(date);
			for(int i=0;i<aList.size();i++){
				if(i==0){
					System.out.println(z+" "+date+"   "+aList.get(i));
					fileList.add(date+"/"+aList.get(i));
					z++;
					continue;
				}
				System.out.println(z+" "+"             "+aList.get(i));
				fileList.add(date+"/"+aList.get(i));
				z++;
			}
		}
		
		System.out.println("\r\n");

		if(fileList.size() == 0){
			start();
		}else{
			while(true){
				System.out.print("Please input something for search or open file: ");
				Scanner scan = new Scanner(System.in);
				String input = scan.nextLine().trim();
				if(input.startsWith("open")){
					openDirOrFile(fileList.get(Integer.parseInt(input.substring(5))));
				}else{
					start();
				}
			}
		}
	}
	
	private Map<String,ArrayList<String>> getAllFiles(){
		Map<String,ArrayList<String>> mMap = new HashMap<String,ArrayList<String>>();
		File dirRoot = new File(suifengDailyRecordPath);
		for(File dirYear : dirRoot.listFiles()){
			for(File dirMonth : dirYear.listFiles()){
				for(File dirDay : dirMonth.listFiles()){
					ArrayList<String> list = new ArrayList<String>();
					for(File file : dirDay.listFiles()){
						if(!checkReg(file.getName())){//�˴���У���ļ��Ƿ�ʹ������Ҫ��
							continue;
						}
						list.add(file.getName());
					}
					if(list.size()>0){
						mMap.put(dirYear.getName()+"/"+dirMonth.getName()+"/"+dirDay.getName(), list);
//						System.out.println(dirYear.getName()+"-"+dirMonth.getName()+"-"+dirDay.getName()+"   "+list.toString());
					}
				}
			}
		}
		return mMap;
	}
	
	/**
	 * ���ҪregΪall����ֱ�ӷ���ture�����ߵ�theme����regʱ���ŷ���true
	 * */
	private boolean checkReg(String theme){
		if("all".equals(reg)){
			return true;
		}else if(theme.contains(reg)){
			return true;
		}
		return false;
	}
	
	/**
	 * ��ָ���ļ����ļ���
	 * 
	 * */
	private void openDirOrFile(String filePath){
		try {
			Runtime.getRuntime().exec(new String[] {"cmd","/c","start","",suifengDailyRecordPath+"/"+filePath});
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		SuifengDailyRecordIndex mSuifengDailyRecordIndex = new SuifengDailyRecordIndex();
		mSuifengDailyRecordIndex.start();
	}

}
